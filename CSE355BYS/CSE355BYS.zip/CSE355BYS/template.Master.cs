﻿using System;

namespace CSE355BYS
{
    public partial class template : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e) { }
    }
}
