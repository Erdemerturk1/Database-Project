﻿using System;

namespace CSE355BYS
{
    public partial class HomePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) { }
    }
}
    