﻿

namespace CSE355BYS
{


    public partial class ProductPage
    {

        /// <summary>
        /// btnQuery denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button btnQuery;

        /// <summary>
        /// gvProducts denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.GridView gvProducts;

        /// <summary>
        /// lblMsg denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblMsg;

        /// <summary>
        /// ddlCategory denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList ddlCategory;

        /// <summary>
        /// txtName denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtName;

        /// <summary>
        /// ddlUnit denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList ddlUnit;

        /// <summary>
        /// ddlCurrency denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList ddlCurrency;

        /// <summary>
        /// txtBasePrice denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtBasePrice;

        /// <summary>
        /// ddlVat denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList ddlVat;

        /// <summary>
        /// txtStock denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtStock;

        /// <summary>
        /// btnAdd denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button btnAdd;
    }
}
